-- AlterTable
ALTER TABLE "public"."CommitteeMessage" ADD COLUMN     "fileURL" TEXT;
