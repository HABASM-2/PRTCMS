-- AlterTable
ALTER TABLE "public"."ProposalVersion" ADD COLUMN     "resubmitAllowed" BOOLEAN NOT NULL DEFAULT false;
