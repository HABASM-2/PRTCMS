-- AlterTable
ALTER TABLE "public"."Project" ADD COLUMN     "totalBudget" DOUBLE PRECISION DEFAULT 0;
