-- AlterTable
ALTER TABLE "public"."User" ADD COLUMN     "isApproved" BOOLEAN NOT NULL DEFAULT false;
