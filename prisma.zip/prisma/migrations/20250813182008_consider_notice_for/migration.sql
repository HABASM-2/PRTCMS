-- AlterTable
ALTER TABLE "public"."ProposalNotice" ADD COLUMN     "consideredFor" TEXT;
