-- AlterTable
ALTER TABLE "public"."Role" ADD COLUMN     "tag" TEXT;
