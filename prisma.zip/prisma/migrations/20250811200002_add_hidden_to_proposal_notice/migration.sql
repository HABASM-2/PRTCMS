-- AlterTable
ALTER TABLE "public"."ProposalNotice" ADD COLUMN     "hidden" BOOLEAN NOT NULL DEFAULT false;
