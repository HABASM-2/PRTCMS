-- AlterTable
ALTER TABLE "public"."ProposalNotice" ADD COLUMN     "isActive" BOOLEAN NOT NULL DEFAULT true;
